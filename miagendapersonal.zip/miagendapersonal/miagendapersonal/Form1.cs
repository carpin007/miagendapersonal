﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace miagendapersonal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'miscontactosdbDataSet.contactos' Puede moverla o quitarla según sea necesario.
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            this.contactosTableAdapter.Fill(this.miscontactosdbDataSet.contactos);


        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            /*contactosTableAdapter.Insert(textBox2.Text, textBox3.Text, DateTime.Now.ToString());
            contactosTableAdapter.Fill(this.miscontactosdbDataSet.contactos);*/
            textBox1.Enabled = false;
            textBox2.Enabled = true;
            textBox2.Focus();
            textBox3.Enabled = true;
            textBox4.Enabled = false;
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
            textBox1.Focus();
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            /*
            // Encontrar fila a borrar
            miscontactosdbDataSet.contactosRow oldcontactosRow;
            oldcontactosRow = miscontactosdbDataSet.contactos.FindByID(Convert.ToInt32(textBox1.Text));
            // borrar la fila del dataset
            oldcontactosRow.Delete();
            //borrar la fila de la base de datos
            this.contactosTableAdapter.Update(this.miscontactosdbDataSet.contactos);
            */
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(Keys.Enter))
            {
                e.Handled = true;
                SendKeys.Send("{TAB}");
                DialogResult resultado = MessageBox.Show("Seguro que quiere eliminar este numero?", "Confirmation", MessageBoxButtons.YesNo);
                if(resultado == DialogResult.Yes)
                {
                    // Encontrar fila a borrar
                    miscontactosdbDataSet.contactosRow oldcontactosRow;
                    oldcontactosRow = miscontactosdbDataSet.contactos.FindByID(Convert.ToInt32(textBox1.Text));
                    // borrar la fila del dataset
                    oldcontactosRow.Delete();
                    //borrar la fila de la base de datos
                    this.contactosTableAdapter.Update(this.miscontactosdbDataSet.contactos);
                }
                else
                {
                    MessageBox.Show("Asegurese de lo que desea hacer!");
                    this.Refresh();
                }
                
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(Keys.Enter))
            {
                e.Handled = true;
                SendKeys.Send("{TAB}");
                DialogResult resultado = MessageBox.Show("Desea agregar el contacto ?","Confirmation",MessageBoxButtons.YesNo);
                if (resultado == DialogResult.Yes)
                {
                    contactosTableAdapter.Insert(textBox2.Text, textBox3.Text, DateTime.Now.ToString());
                    contactosTableAdapter.Fill(this.miscontactosdbDataSet.contactos);
                }
                else
                {
                    MessageBox.Show("Operacion Rechazada");
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
    }
}
