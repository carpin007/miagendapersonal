﻿using System;
using Gtk;

namespace miprimerappmono
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Application.Init ();
			miprimerappmono.Window win = new miprimerappmono.Window ();
			win.Show ();
			Application.Run ();
		}
	}
}
