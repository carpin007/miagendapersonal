﻿using System;
using Gtk;
using System.Data;
using System.Data.SQLite;


namespace miprimerappmono
{
	public partial class Window : Gtk.Window
	{
		SQLiteDataReader reader;
		Gtk.ListStore clientesListStore;
		public Window () :
			base (Gtk.WindowType.Toplevel)
		{
			this.Build ();
			creargrid ();
			leerdatos ();
		}

		protected void OnBtnSalirClicked (object sender, EventArgs e)
		{
			Application.Quit ();
		}

		protected void OnBtnGuardarClicked (object sender, EventArgs e)
		{
			string cadena = "Data Source = misdatos.db";
			SQLiteConnection conexion = new SQLiteConnection(cadena);
			SQLiteCommand cmd = new SQLiteCommand("insert into clientes (nombre,direccion,zona) values(@nombre,@direccion,@zona)", conexion);
			cmd.Prepare ();
			cmd.Parameters.AddWithValue ("@nombre", txtNombre.Text);
			cmd.Parameters.AddWithValue ("@direccion", txtDireccion.Text);
			cmd.Parameters.AddWithValue ("@zona",txtZona.Text);
			try 
			{
				conexion.Open();
				cmd.ExecuteNonQuery();
				MessageDialog md = new MessageDialog(null,DialogFlags.Modal,MessageType.Info,ButtonsType.Ok,"Reguistro se guardo Correctamente");
				md.Run();
				md.Destroy();
				txtNombre.Text = txtDireccion.Text = txtZona.Text = "";	

			} 
			catch (SQLiteException ex) 
			{
				//Console.WriteLine (ex.Message);
				MessageDialog md = new MessageDialog(null, DialogFlags.Modal, MessageType.Info, ButtonsType.Ok, ex.Message);

			} 
			finally 
			{
				conexion.Close ();
			}
		}
		private void creargrid()
		{
			clientesListStore = new Gtk.ListStore (typeof(Int64), typeof(string), typeof(string), typeof(string));
			treeview1.AppendColumn ("ID", new Gtk.CellRendererText (), "text", 0);
			treeview1.AppendColumn ("Nombre", new Gtk.CellRendererText (), "text", 1);
			treeview1.AppendColumn ("Direccion", new Gtk.CellRendererText (), "text", 2);
			treeview1.AppendColumn ("Zona", new Gtk.CellRendererText (), "text", 3);
			treeview1.Model = clientesListStore;

		}
		private void leerdatos ()
		{
			
			string cadenalectura = "Data Source = misdatos.db";
			SQLiteConnection conector = new SQLiteConnection(cadenalectura);
			string consulta = "select id, nombre, direccion, zona from clientes";
			SQLiteCommand cmd = new SQLiteCommand(consulta,conector);
			try 
			{
				conector.Open();
				reader = cmd.ExecuteReader ();
				while (reader.Read ()) 
				{
					clientesListStore.AppendValues (reader.GetInt64(0), reader.GetString(1), reader.GetString(2), reader.GetString(3));
					//Console.WriteLine("{0}\t{1}\t{2}\t{3}",reader.GetInt64(0), reader.GetString(1), reader.GetString(2), reader.GetString(3));

				}

			}
			catch (SQLiteException e) 
			{
				Console.Write (e.Message);
			}
			finally 
			{
				reader.Close ();
				conector.Close();
			}

		}

		protected void OnBtnRefrescarClicked (object sender, EventArgs e)
		{
			clientesListStore.Clear ();
			leerdatos ();
		}
	}
}

